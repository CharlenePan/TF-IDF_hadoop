package comp9313.proj1;


import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


import java.io.IOException;
import java.util.*;

/**
 * TFIDF reducer
 */
public class TFIDFReducer
        extends Reducer<Text, Text, Text, Text> {


    static class Record {

        int docId;

        int numOccurance;

        public Record(int docId, int numOccurance) {
            this.docId = docId;
            this.numOccurance = numOccurance;
        }
    }

    static int N;


    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        N = context.getConfiguration().getInt("N", 1);
    }

    public void reduce(Text key, Iterable<Text> values,
                       Context context
    ) throws IOException, InterruptedException {

        List<Record> records = new ArrayList<>();

        for (Text text : values) {

            String t[] = text.toString().split(" ");

            int numOccur = Integer.parseInt(t[1]);

            records.add(new Record(Integer.parseInt(t[0]), numOccur));

        }


        Collections.sort(records, new Comparator<Record>() {
            @Override
            public int compare(Record o1, Record o2) {
                return o1.docId - o2.docId;
            }
        });

        for (Record record : records) {

            double res = record.numOccurance * Math.log10(N * 1.0 / records.size());

            context.write(key, new Text(record.docId + "," + res));


        }

    }

}
