package comp9313.proj1;


import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapreduce.Mapper;


import java.io.IOException;
import java.util.*;
/**
     * TFIDF mapper
     */
    public  class TFIDFMapper

            extends Mapper<Object, Text, Text, Text> {


        public void map(Object key, Text value, Context context

        ) throws IOException, InterruptedException {


            String t[] = value.toString().toLowerCase().split(" ");

            int docId = Integer.parseInt(t[0]);

            Map<String, Integer> counts = new HashMap<>();

            for (int i = 1; i < t.length; i++) {

                if (counts.containsKey(t[i])) {

                    counts.put(t[i], counts.get(t[i]) + 1);
                } else {

                    counts.put(t[i], 1);
                }
            }

            for (String w : counts.keySet()) {

                context.write(new Text(w), new Text(docId + " " + counts.get(w)));
            }
        }
    }