package comp9313.proj1;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.IOException;
import java.util.*;

public class Project1 {

    // number of docs
    static int N;


    public static enum NCounter {
        NCounter
    };

    /**
     * count docs mapper
     */
    public static class CountMapper

            extends Mapper<Object, Text, Text, IntWritable> {


        Text text = new Text("A");

        IntWritable one = new IntWritable(1);

        public void map(Object key, Text value, Context context

        ) throws IOException, InterruptedException {

            context.write(text, one);
        }
    }


    /**
     * count docs reducer
     */
    public static class CountReducer
            extends Reducer<Text, IntWritable, Text, IntWritable> {


        public void reduce(Text key, Iterable<IntWritable> values,
                           Context context
        ) throws IOException, InterruptedException {

            int total = 0;

            for (IntWritable intWritable : values) {

                total += intWritable.get();
            }

            context.write(new Text("count"), new IntWritable(total));

//            N = total;

//            context.getConfiguration().setInt("N", total);


            context.getCounter(NCounter.NCounter).setValue(total);
        }

    }


    /**
     * count the docs
     *
     * @param input
     * @param output
     * @throws IOException
     * @throws ClassNotFoundException
     * @throws InterruptedException
     */
    static int runBefore(String input, String output) throws IOException, ClassNotFoundException, InterruptedException {
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "count");
        job.setJarByClass(Project1.class);
        job.setMapperClass(CountMapper.class);
        job.setReducerClass(CountReducer.class);


        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);

        job.setNumReduceTasks(1);

        FileInputFormat.addInputPath(job, new Path(input));
        FileOutputFormat.setOutputPath(job, new Path(output));

        job.waitForCompletion(true);

        System.out.println("N------------");




        int x =  (int) (job.getCounters().findCounter(NCounter.NCounter).getValue());


        System.out.println(x);
        return x;
//        return conf.getInt("N", 1);
    }


    public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {


        String input = args[0];

        String output = args[1];

        int numReducer = Integer.parseInt(args[2]);

        int N = runBefore(input, "countoutput" + new Date().getTime());


        Configuration conf = new Configuration();

        conf.setInt("N", N);
        Job job = Job.getInstance(conf, "proj1");

        FileInputFormat.addInputPath(job, new Path(input));
        FileOutputFormat.setOutputPath(job, new Path(output));

        job.setJarByClass(Project1.class);
        job.setMapperClass(TFIDFMapper.class);
        job.setReducerClass(TFIDFReducer.class);


        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        job.setNumReduceTasks(numReducer);



        job.waitForCompletion(true);
    }
}
